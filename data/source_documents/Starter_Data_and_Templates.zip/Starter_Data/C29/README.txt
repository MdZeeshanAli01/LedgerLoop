Appointment Recovery Desk

Engineering outcome: Show cancellations and waiting-list matches; record customer consent and rebook; prevent duplicate slot allocation.

MBA opportunity: Salon or tutoring centre owner. Per-location subscription (hypothesis).
Product change to negotiate: Add service-duration and staff constraints before outreach
Skills: Service operations, customer research, pricing

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
