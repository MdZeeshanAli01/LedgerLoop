Supplier Quote Comparison Desk

Engineering outcome: Normalize pack sizes and costs; compare landed cost, lead time and MOQ; save a recommendation with exceptions.

MBA opportunity: Small manufacturer procurement lead. Per-buyer subscription (hypothesis).
Product change to negotiate: Add pack normalization and delivery constraints
Skills: Procurement, supplier negotiation, working capital

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
