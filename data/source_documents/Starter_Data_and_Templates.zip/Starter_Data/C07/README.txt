Budget Based Product Bundle Builder

Engineering outcome: Use one activity and required item slots; choose available items; replace one item; recompute total and validity.

MBA opportunity: Work-from-home accessory retailer. Retailer tool fee or disclosed basket referral fee (hypothesis).
Product change to negotiate: Add compatibility and landed-price comparison
Skills: Category management, packaging, conversion research

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
