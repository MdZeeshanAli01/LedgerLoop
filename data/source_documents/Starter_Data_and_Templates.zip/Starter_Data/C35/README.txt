Freelancer Scope Change Desk

Engineering outcome: Compare a request against agreed deliverables; identify changes; estimate effort with assumptions; create a versioned approval record.

MBA opportunity: Small agency owner. Per-seat subscription (hypothesis).
Product change to negotiate: Add approval state and effort capacity before auto-quotes
Skills: Professional-services economics, client negotiation, scope control

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
