Order Contribution and Profit Leak Desk

Engineering outcome: Import order economics; reconcile per-order contribution to channel/product totals; compare a controlled cost/refund scenario; save the decision.

MBA opportunity: Small D2C founder. Monthly contribution-report subscription (hypothesis).
Product change to negotiate: Add refund and recovery semantics before a profit headline
Skills: Unit economics, accounting literacy, founder sales

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
