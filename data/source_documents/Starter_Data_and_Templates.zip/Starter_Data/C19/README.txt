Inventory Forecast and Replenishment Baseline

Engineering outcome: Forecast seven-day demand for 5 SKUs; compare a naive baseline; estimate coverage and proposed quantities with lead times.

MBA opportunity: Small chain inventory planner. Per-location planning subscription (hypothesis).
Product change to negotiate: Add MOQ and stockout handling before a complex model
Skills: Demand planning, working capital, uncertainty analysis

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
