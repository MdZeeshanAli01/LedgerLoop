Smart Meeting Preparation Agent

Engineering outcome: Use one agenda and 5–10 documents; produce a concise briefing with dated citations and unresolved questions.

MBA opportunity: Account management team. Per-seat monthly subscription (hypothesis).
Product change to negotiate: Add decision history and unresolved issues to the brief
Skills: B2B sales, account planning, willingness-to-pay research

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
