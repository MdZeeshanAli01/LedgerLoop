Automated Chaser Draft Queue

Engineering outcome: Extract actions from synthetic conversations; maintain owner/deadline/status; draft reminders; suppress after completion.

MBA opportunity: Professional-services delivery manager. Team subscription (hypothesis).
Product change to negotiate: Add stale-message suppression and recipient review
Skills: Project operations, stakeholder communication, adoption

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
