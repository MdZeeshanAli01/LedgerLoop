Voice to Cart Assistant

Engineering outcome: Record a short request; show editable transcript and parsed quantity; retrieve products; confirm before updating a demo cart.

MBA opportunity: Mobile commerce retailer. Per-store fee or tested assisted-conversion tier (hypothesis).
Product change to negotiate: Add confirmation, correction and text fallback
Skills: Accessibility research, funnel analysis, category strategy

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
