Screenshot to Shop Assistant

Engineering outcome: Accept one main-product image; return up to five catalogue matches with prices; refine by category or budget.

MBA opportunity: Visual-commerce retailer. Usage-based discovery service (hypothesis).
Product change to negotiate: Add a difference explanation and a manual recovery path
Skills: Search merchandising, customer research, attribution

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
