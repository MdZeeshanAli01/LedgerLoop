Slack to Jira Ticket Assistant

Engineering outcome: Load one fictional Slack thread; preview issue summary, impact and acceptance criteria; check duplicates; confirm creation; retrieve status.

MBA opportunity: Engineering support lead. Per-workspace subscription (hypothesis).
Product change to negotiate: Add approval and idempotency before live ticket creation
Skills: Workflow design, internal sales, adoption economics

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
