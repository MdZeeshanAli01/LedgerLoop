Out of Stock Alternative Finder

Engineering outcome: Choose an unavailable SKU; retrieve up to three available substitutes; explain differences; recalculate after a requirement change.

MBA opportunity: D2C merchandising team. Monthly fee plus a clearly defined recovery tier (hypothesis).
Product change to negotiate: Add hard requirements and a no-match path
Skills: Merchandising, customer research, contribution analysis

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
