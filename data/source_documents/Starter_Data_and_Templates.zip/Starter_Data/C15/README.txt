Advanced Daily Summary Agent

Engineering outcome: Import one day of fictional multi-source updates; deduplicate; produce a cited digest grouped by work item.

MBA opportunity: Distributed engineering manager. Team subscription (hypothesis).
Product change to negotiate: Add corrections and critical blockers instead of more volume
Skills: Organisational behaviour, communication design, productivity measurement

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
