Return Management and Feedback Loop

Engineering outcome: Enter request and order facts; evaluate supplied policy; explain recommendation; save a local case; aggregate reason counts.

MBA opportunity: Retail returns operations team. Monthly fee tied to case volume (hypothesis).
Product change to negotiate: Add appeal and exception handling rather than blanket rejection
Skills: Service design, returns economics, policy communication

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
