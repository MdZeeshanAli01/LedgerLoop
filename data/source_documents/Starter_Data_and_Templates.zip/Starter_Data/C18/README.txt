Checkout Drop Off Investigator

Engineering outcome: Compare two periods; compute session-based step conversion by device/payment segment; show the largest decline with evidence.

MBA opportunity: Ecommerce growth lead. Monthly analytics subscription (hypothesis).
Product change to negotiate: Add instrumentation gaps and segment comparisons
Skills: Funnel analysis, experimentation, measurement design

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
