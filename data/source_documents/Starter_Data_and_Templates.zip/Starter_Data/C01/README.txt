Review to Action Merchant Copilot

Engineering outcome: Import 20 reviews; show three issue groups, affected products, unique review counts and linked evidence; save a reviewed action.

MBA opportunity: Small D2C quality team. Monthly subscription per store (hypothesis).
Product change to negotiate: Add severity and ownership rather than a word cloud
Skills: Customer research, service operations, value-based pricing

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
