Returned Stock Recovery Planner

Engineering outcome: Load inspected lots; compare resale/refurbish/scrap scenarios; enforce eligibility/capacity; save a reviewed proposal.

MBA opportunity: Returns warehouse operator. Per-site workflow subscription (hypothesis).
Product change to negotiate: Add inspection and recovery uncertainty to the routing screen
Skills: Recovery economics, operations, quality control

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
