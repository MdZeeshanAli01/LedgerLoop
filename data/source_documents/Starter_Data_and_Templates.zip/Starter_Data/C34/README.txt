Event Sponsorship Match Desk

Engineering outcome: Match a sponsor brief to event inventory; price a package; prevent double-selling exclusive slots; track obligations.

MBA opportunity: Local sponsor or event organiser. Paid package-planning service (hypothesis).
Product change to negotiate: Add exclusivity and fulfilment tracking
Skills: Partnerships, audience research, negotiation

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
