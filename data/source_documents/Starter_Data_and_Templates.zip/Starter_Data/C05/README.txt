Auto Coupon Cart Optimization Agent

Engineering outcome: Load a cart and 5–10 offers; enumerate permitted combinations; display eligible/rejected offers, savings, shipping and total.

MBA opportunity: Merchant promotions team. Monthly validation subscription (hypothesis).
Product change to negotiate: Add margin and shipping transparency to the cheapest-price screen
Skills: Promotion economics, pricing, stakeholder negotiation

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
