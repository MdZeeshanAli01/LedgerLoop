Group Stay Quote Builder

Engineering outcome: Build a dated group quote; check room types and nights; calculate package contribution and expiry.

MBA opportunity: Small hotel owner. Per-property subscription or quote workflow fee (hypothesis).
Product change to negotiate: Add room-night availability and quote expiry
Skills: Hospitality sales, yield management, contribution analysis

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
