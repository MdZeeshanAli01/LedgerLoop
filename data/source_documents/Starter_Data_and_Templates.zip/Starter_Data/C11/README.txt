Price Validation and Benchmarking Agent

Engineering outcome: Import own and competitor snapshots; match equivalent variants; flag seeded anomalies; show evidence and normalized differences.

MBA opportunity: Retail pricing operations team. Per-store or catalogue subscription (hypothesis).
Product change to negotiate: Add equivalent-pack matching before price alerts
Skills: Category economics, competitive research, pricing governance

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
