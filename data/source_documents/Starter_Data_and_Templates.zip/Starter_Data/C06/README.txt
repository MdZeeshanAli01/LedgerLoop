Duplicate Product Review Queue

Engineering outcome: Inspect 20 products; propose duplicate pairs with matching evidence; accept or reject; export the reviewed queue.

MBA opportunity: Marketplace catalogue team. Monthly review-seat fee (hypothesis).
Product change to negotiate: Add review evidence and false-merge cost before bulk automation
Skills: Operations design, quality economics, B2B sales

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
