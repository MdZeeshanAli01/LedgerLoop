Store Turnaround Decision Simulator

Engineering outcome: Reconcile monthly store profit; compare three six-month scenarios; show break-even assumptions and one-off costs.

MBA opportunity: Small retail chain owner. Per-store planning subscription (hypothesis).
Product change to negotiate: Add cash timing and lease exits to a profit-only view
Skills: Retail finance, turnaround planning, stakeholder alignment

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
