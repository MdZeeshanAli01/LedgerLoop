Subscription Renewal Desk

Engineering outcome: Combine renewal dates, activity and service issues; show evidence and a proposed next action; log follow-up.

MBA opportunity: Small SaaS founder. Per-account-band subscription (hypothesis).
Product change to negotiate: Add usage freshness and a specific owner action
Skills: Customer success, cohort reasoning, SaaS economics

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
