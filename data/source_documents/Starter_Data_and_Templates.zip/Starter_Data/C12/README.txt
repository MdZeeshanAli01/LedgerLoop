Damaged Product Evidence Assistant

Engineering outcome: Upload photos and complaint; summarize visible observations, quoted claims and missing evidence; retain reviewer decision.

MBA opportunity: Marketplace support team. Per reviewed claim or agent-seat fee (hypothesis).
Product change to negotiate: Add an uncertainty flag and reviewer confirmation
Skills: Support operations, fraud-cost trade-offs, customer fairness

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
