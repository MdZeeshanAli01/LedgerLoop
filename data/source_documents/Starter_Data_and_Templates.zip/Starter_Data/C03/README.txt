AI Gift Finder

Engineering outcome: Ask recipient interests, occasion and budget; retrieve up to five catalogue products with grounded reasons; refine after feedback.

MBA opportunity: Independent gifting retailer. Retailer subscription or disclosed referral fee (hypothesis).
Product change to negotiate: Add corporate bulk gifting or an editable preference flow
Skills: Segmentation, positioning, channel partnerships

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
