Product Image Description Review Tool

Engineering outcome: Process ten supplied images; draft descriptions; edit and approve per image; export product_id and final description.

MBA opportunity: Merchant catalogue team. Usage tiers per reviewed image (hypothesis).
Product change to negotiate: Add reviewer approval and inaccessible-image handling
Skills: Content operations, adoption research, service pricing

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
