Perishable Stock Recovery Desk

Engineering outcome: Show ageing stock; simulate markdowns; allocate quantities and record the recommended action.

MBA opportunity: Cafe or grocery owner. Per-location subscription (hypothesis).
Product change to negotiate: Add expiry checks before an attractive recovery number
Skills: Inventory economics, demand scenarios, operations

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
