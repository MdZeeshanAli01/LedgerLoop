Natural Language Commerce Analytics Assistant

Engineering outcome: Support five declared question types over supplied data; show answer, date range, chart and query; clarify ambiguity.

MBA opportunity: Small retail chain finance lead. Subscription per store or analyst seat (hypothesis).
Product change to negotiate: Add metric definitions and an exportable audit trail
Skills: Financial analysis, metric design, buyer interviews

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
