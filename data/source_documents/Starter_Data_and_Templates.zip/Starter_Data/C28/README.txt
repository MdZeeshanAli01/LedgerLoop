B2B Receivables Follow Up Desk

Engineering outcome: Import invoices and receipts; calculate overdue balance; separate disputes; draft a reviewable follow-up plan.

MBA opportunity: Small distributor finance lead. Monthly operations subscription (hypothesis).
Product change to negotiate: Add disputes and partial receipts to collection priority
Skills: Receivables operations, cash-flow analysis, communication

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
