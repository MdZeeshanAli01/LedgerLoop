Repair Visit Parts Planner

Engineering outcome: Match fault category, technician skill and parts; plan a feasible visit; explain blockers.

MBA opportunity: Repair service owner. Per-technician or location subscription (hypothesis).
Product change to negotiate: Add parts availability and diagnostic uncertainty
Skills: Service operations, capacity planning, supplier coordination

All fields ending _inr are INR, _pct are percent from 0 to 100, _units are counts, _days are calendar days; ISO dates use stated as-of dates. Descriptive fields are synthetic. The exact common data keys are visible in fixture.json. Do not combine this fixture with the old MBA workbook without explicit mapping.
