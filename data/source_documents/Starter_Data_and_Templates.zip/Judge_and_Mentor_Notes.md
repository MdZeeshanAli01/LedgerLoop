# Judge and mentor setup notes

Use Version 3 case IDs C01-C35. All data is synthetic. Each fixture has records, three public checks, assumptions and limits. Public checks are transparent reference tests, not a secret accuracy benchmark. Do not treat repeated synthetic image queries as independent real-world search validation.

Before judging, run the reference calculation and one changed-input challenge for the selected case. Judge the published bounded scope; text/manual/mock fallbacks are valid when disclosed. Technical scores combine the common rubric and three case checks at 10/10/5. MBA scores use the seven dimensions in Judging_Rubric.csv and each case's payer, model, growth and product-change assignment.

The MBA comparison is baseline to final: what was inherited, what decision the MBA team made, and what changed. A sophisticated inherited prototype should not win business points by itself. Ask each participant one contribution question. Reward evidenced recruiting fit and a constructive declined offer; do not count poached people.

Public data coverage: C05 has ten cart boundaries; C07 ten bundle budgets; C08 ten computed reference questions; C09 twenty queries from ten synthetic images; C11 ten labelled equivalence pairs; C12 ten evidence cases; C13 five explicit open decisions; C14 ten actions and a deadline correction; C15 five critical facts; C18 two periods and a duplicate event; C19 five SKUs with chronological holdout and five inventory examples. Other cards carry direct cases or worked calculations. These are deliberately small fixtures, not a certified model benchmark.

For an unseen challenge, change one stated input and retain the rule. Examples: lower budget below the cheapest feasible bundle, set stock to zero, move the date past a policy boundary, raise a cost, remove a required field, or repeat an already confirmed action. Write the expected behaviour before running the product. Do not silently add a new feature requirement.

For the 9 AM market shock, give everyone the same window. Choose a comparable change from the card's edge cases. Grade the response, trade-off, changed product and business consequence. Freeze only case ownership and people rosters; ordinary product negotiations and evidence may continue until submission. The page supports this distinction.

Use three judging rooms for the proposed 1–2:10 PM first round: ten teams per room × seven minutes (four presentation, three questions). Two finalists from each room give six five-minute final slots. Publish any alternative timing before the event.

Practical release decisions for Diwakar: confirm final team counts, MBA intake cutoff, freeze and finish times; appoint operator, transfer desk and three technical/business judging pairs. No prizes, internships or live production guarantees are created by this pack.
